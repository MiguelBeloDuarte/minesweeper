import kotlin.math.abs
import java.io.File

fun criaMenu(): String {
    return "\nBem vindo ao Campo DEISIado\n\n1 - Novo Jogo\n2 - Ler Jogo\n0 - Sair\n"
}

fun validaNome(nome: String, tamanhoMinimo: Int = 3): Boolean {
    var espaco = 0
    var posAtual = 0
    while (posAtual < nome.length) {   //Percorre todos as letras do nome
        val caracterAtual = nome[posAtual]
        if (caracterAtual == ' ') {   //Se há espaço incrementa na variável
            espaco++
        }
        posAtual++
    }
    if (espaco != 1) return false   //Só pode ter 1 espaço
    var pos = -1
    var posAtual2 = 0
    while (posAtual2 < nome.length && pos == -1) {   //Procura o primeiro espaço
        val letra = nome[posAtual2]
        if (letra == ' ') {
            pos = posAtual2
        }
        posAtual2++
    }
    if (pos == -1) return false   //Se não houver espaço, é inválido
    val tamanhoPrimeiro = pos
    val tamanhoUltimo = nome.length - pos - 1
    if (tamanhoPrimeiro < tamanhoMinimo || tamanhoUltimo < tamanhoMinimo) {   //Cada nome tem de ter, pelo menos, 3 letras
        return false
    }
    if (!nome[0].isUpperCase()) return false   //Primeira letra do nome maiúscula
    if (!nome[pos + 1].isUpperCase()) return false   //Primeira letra do apelido maiúscula
    var posAtual3 = 1
    while (posAtual3 < pos) {   //Verifica o tamaho do nome antes do espaço
        val caracterAtual2 = nome[posAtual3]
        if (!caracterAtual2.isLowerCase()) return false   //A seguir á primeira maiúscula, tudo minúsculas
        posAtual3++
    }
    var posAtual4 = pos + 2
    while (posAtual4 < nome.length) {   //Verifica o tamanho do apelido depois do nome e espaço
        val caracterAtual3 = nome[posAtual4]
        if (!caracterAtual3.isLowerCase()) return false   //A seguir á primeira maiúscula, tudo minúsculas
        posAtual4++
    }
    return true
}

fun validaNumeroDeMinas(linhas: Int, colunas: Int, numMinas: Int): Boolean {
    val maxMinas = linhas * colunas - 2   //Max de minas, com 2 espaços a menos (J e f)
    if (linhas <= 0 || colunas <= 0 || colunas > 26) return false
    if (numMinas < 1 || maxMinas < 1) return false
    return numMinas <= maxMinas
}

fun calculaNumeroDeMinas(linhas: Int, colunas: Int): Int {
    val espacos = linhas * colunas - 2
    return when {
        espacos <= 1 -> 1
        espacos >= 2 && espacos <= 5 -> 2
        espacos >= 6 && espacos <= 10 -> 3
        espacos >= 11 && espacos <= 20 -> 6
        espacos >= 21 && espacos <= 50 -> 10
        else -> 15
    }
}

fun criaLegenda(colunas: Int): String {
    var legenda = ""
    var letra = 'A'
    var limite = 1
    while (limite <= colunas && letra <= 'Z') {
        if (limite < colunas) {
            legenda += "$letra   "
        }
        if (limite == colunas) {
            legenda += "$letra"
        }
        letra++
        limite++
    }
    return legenda
}

fun obtemCoordenadas(coordenadas: String?): Pair<Int, Int>? {
    if (coordenadas == null) return null

    val cordlimpas = coordenadas.trim()   //Remove espaços á volta
    if (cordlimpas.length < 2) return null

    fun colIndex(c: Char): Int =   //Conversão da letra para posição nas coordenadas
        when {
            c in 'A'..'Z' -> c - 'A'
            c in 'a'..'z' -> c - 'a'
            else -> -1
        }

    val ultimo = cordlimpas.last()
    val primeiro = cordlimpas.first()

    if (ultimo.isLetter()) {   //Caso receba ex: 2D
        val linhaNumero = cordlimpas.dropLast(1).trim().toIntOrNull() ?: return null
        val coluna = colIndex(ultimo)
        if (coluna != -1) return Pair(linhaNumero - 1, coluna)
    }

    if (primeiro.isLetter()) {   //Caso receba ex: D2
        val linhaNumero = cordlimpas.drop(1).trim().toIntOrNull() ?: return null
        val coluna = colIndex(primeiro)
        if (coluna != -1) return Pair(linhaNumero - 1, coluna)
    }

    return null
}

fun validaCoordenadasDentroTerreno(coord: Pair<Int, Int>?, numLinhas: Int, numColunas: Int): Boolean {
    if (coord == null) return false   //Coordenadas inexistentes são inválidas

    val linha = coord.first
    val coluna = coord.second

    return !(linha < 0 || linha >= numLinhas || coluna < 0 || coluna >= numColunas)
}

fun geraMatrizTerreno(numLinhas: Int, numColunas: Int, numMinas: Int): Array<Array<Pair<String, Boolean>>> {
    val matriz = Array(numLinhas) { Array(numColunas) { Pair(" ", false) } }   //Cria matriz para conteúdo visível (linhas, colunas) e (" ", escondido)

    matriz[0][1] = Pair("J", true)   //Jogador visível na coord (0,1)
    matriz[numLinhas - 1][numColunas - 1] = Pair("f", true)   //Final visível nas coordenadas finais

    val totalCelulas = numLinhas * numColunas
    val posicoes = Array(totalCelulas) { false }   //Marca células ocupadas

    posicoes[0] = true   //Posição do J
    posicoes[totalCelulas - 1] = true   //Posição do f

    var minasColocadas = 0
    while (minasColocadas < numMinas) {   //Minas aleatórias
        val posicaoAleatoria = (1 until totalCelulas).random()
        if (!posicoes[posicaoAleatoria]) {
            posicoes[posicaoAleatoria] = true
            minasColocadas++
        }
    }

    var linhas = 0
    while (linhas < numLinhas) {
        var colunas = 0
        while (colunas < numColunas) {
            val indice1D = linhas * numColunas + colunas
            if (posicoes[indice1D]) {
                val conteudo = matriz[linhas][colunas].first
                if (conteudo != "J" && conteudo != "f") {   //Se não for J nem f, pode ter mina
                    matriz[linhas][colunas] = Pair("*", false)
                }
            }
            colunas++
        }
        linhas++
    }

    return matriz
}

fun validaMovimentoJogador(origem: Pair<Int, Int>, destino: Pair<Int, Int>): Boolean {
    val diffLinha = if (origem.first > destino.first) origem.first - destino.first else destino.first - origem.first
    val diffColuna = if (origem.second > destino.second) origem.second - destino.second else destino.second - origem.second

    if (diffLinha == 0 && diffColuna == 0) {   //Não pode ficar parado
        return false
    }

    if (diffLinha == 1 && diffColuna == 1) return true  //Pode mover na diagonal

    if (diffLinha == 2 && diffColuna == 2) return true  //Pode mover na diagonal

    return diffLinha <= 0 && diffColuna <= 2   //Mov max de 2 células horizontalmente
}

fun quadradoAVoltaDoPonto(linha: Int, coluna: Int, numLinhas: Int, numColunas: Int): Pair<Pair<Int, Int>, Pair<Int, Int>> {
    val linhaMin = if (linha > 0) linha - 1 else 0
    val colunaMin = if (coluna > 0) coluna - 1 else 0
    val linhaMax = if (linha < numLinhas - 1) linha + 1 else numLinhas - 1
    val colunaMax = if (coluna < numColunas - 1) coluna + 1 else numColunas - 1

    return Pair(Pair(linhaMin, colunaMin), Pair(linhaMax, colunaMax))
}

fun contaMinasPerto(matriz: Array<Array<Pair<String, Boolean>>>, linha: Int, coluna: Int): Int {
    val limites = quadradoAVoltaDoPonto(linha, coluna, matriz.size, matriz[0].size)
    var minas = 0

    var linhas = limites.first.first
    while (linhas <= limites.second.first) {
        var colunas = limites.first.second
        while (colunas <= limites.second.second) {
            if (linhas != linha || colunas != coluna) {   //Ignora a célula
                if (matriz[linhas][colunas].first == "*") minas++
            }
            colunas++
        }
        linhas++
    }
    return minas
}

fun preencheNumMinasNoTerreno(matriz: Array<Array<Pair<String, Boolean>>>) {
    var linha = 0
    while (linha < matriz.size) {
        var coluna = 0
        while (coluna < matriz[0].size) {
            if (matriz[linha][coluna].first == " ") {   //Só mexe em casas vazias
                val numMinas = contaMinasPerto(matriz, linha, coluna)
                if (numMinas > 0) {
                    matriz[linha][coluna] =
                        Pair(numMinas.toString(), false)   //Guarda o nº de minas como texto, mas está escondido
                }
            }
            coluna++
        }
        linha++
    }
}

fun criaTerreno(matriz: Array<Array<Pair<String, Boolean>>>, mostraLegenda: Boolean = true, mostraTudo: Boolean = false): String {
    val linhas = matriz.size
    val colunas = matriz[0].size
    var resultado = ""

    if (mostraLegenda) {
        resultado += "    " + criaLegenda(colunas) + "    \n"
    }

    for (i in 0 until linhas) {
        var linhaStr = ""
        if (mostraLegenda) {
            val numerolinhas = i + 1
            linhaStr += if (numerolinhas < 10) " $numerolinhas " else "$numerolinhas "
        }

        for (j in 0 until colunas) {
            val (conteudo, visivel) = matriz[i][j]
            val valor = if (mostraTudo || visivel) conteudo else " "
            if (j > 0) linhaStr += "|"
            linhaStr += " $valor "
        }

        if (mostraLegenda) {

            linhaStr += "   "
        }

        resultado += linhaStr

        if (i < linhas - 1) {
            resultado += "\n"
            var separador = ""
            var coluna = 0
            while (coluna < colunas) {
                separador += "---"
                if (coluna < colunas - 1) separador += "+"
                coluna++
            }
            if (mostraLegenda) {
                resultado += "   $separador   \n"
            } else {
                resultado += separador + "\n"
            }
        }
    }
    if(mostraLegenda) {
        resultado += "\n"
    }
    return resultado
}

fun revelaMatriz(matriz: Array<Array<Pair<String, Boolean>>>, linha: Int, coluna: Int) {
    if (!validaCoordenadasDentroTerreno(Pair(linha, coluna), matriz.size, matriz[0].size)) return

    val limites = quadradoAVoltaDoPonto(linha, coluna, matriz.size, matriz[0].size)

    var linha = limites.first.first
    while (linha <= limites.second.first) {
        var coluna = limites.first.second
        while (coluna <= limites.second.second) {
            val conteudo = matriz[linha][coluna].first

            if (conteudo != "*") {
                matriz[linha][coluna] = Pair(conteudo, true)   //Revela tudo á volta sem ser a mina
            }
            coluna++
        }
        linha++
    }
}

fun escondeMatriz(matriz: Array<Array<Pair<String, Boolean>>>) {
    var linha = 0
    while (linha < matriz.size) {
        var coluna = 0
        while (coluna < matriz[0].size) {
            val conteudo = matriz[linha][coluna].first
            if (conteudo != "J" && conteudo != "f") {
                matriz[linha][coluna] = Pair(conteudo, false)   //Esconde tudo exceto J e f
            }
            coluna++
        }
        linha++
    }
}

fun celulaTemNumeroMinasVisivel(matriz: Array<Array<Pair<String, Boolean>>>, linha: Int, coluna: Int): Boolean {
    if (!validaCoordenadasDentroTerreno(Pair(linha, coluna), matriz.size, matriz[0].size)){
        return false}

    val (conteudo, visivel) = matriz[linha][coluna]
    return visivel && conteudo.length == 1 && conteudo[0] in '1'..'9'
}

fun lerFicheiroJogo(nomeDoFicheiro: String?, numLinhas: Int, numColunas: Int): Array<Array<Pair<String, Boolean>>> {
    val ficheiro = File(nomeDoFicheiro)

    if (ficheiro.exists() == true) {   //Lê se o ficheiro existir
        val listaDeLinhas = ficheiro.readLines()

        var linhasFinais = numLinhas
        if (numLinhas == 0) {
            linhasFinais = listaDeLinhas.size
        }

        var colunasFinais = numColunas
        if (numColunas == 0) {
            if (listaDeLinhas.isNotEmpty()) {
                val primeiraLinhaTexto = listaDeLinhas[0]
                if (primeiraLinhaTexto.contains(",")) {
                    colunasFinais = primeiraLinhaTexto.split(",").size
                } else {
                    colunasFinais = primeiraLinhaTexto.length
                }
            } else {
                colunasFinais = 0
            }
        }

        val matrizResultado = Array(linhasFinais) { Array(colunasFinais) { Pair(" ", false) } }

        var indiceLinha = 0
        while (indiceLinha < linhasFinais) {
            if (indiceLinha < listaDeLinhas.size) {
                val textoDaLinha = listaDeLinhas[indiceLinha]
                var listaColunasDaLinha: List<String>

                if (textoDaLinha.contains(",")) {
                    listaColunasDaLinha = textoDaLinha.split(",")
                } else {
                    var listaTemporaria = emptyList<String>()
                    var contadorChar = 0
                    while (contadorChar < textoDaLinha.length) {
                        listaTemporaria = listaTemporaria + textoDaLinha[contadorChar].toString()
                        contadorChar++
                    }
                    listaColunasDaLinha = listaTemporaria
                }

                var indiceColuna = 0
                while (indiceColuna < colunasFinais) {
                    if (indiceColuna < listaColunasDaLinha.size) {
                        var valorCelula = listaColunasDaLinha[indiceColuna].trim()
                        if (valorCelula == "") valorCelula = " "

                        var visivelInicialmente = false
                        if (valorCelula == "J" || valorCelula == "f") {   //J e f começam visíveis
                            visivelInicialmente = true
                        }
                        matrizResultado[indiceLinha][indiceColuna] = Pair(valorCelula, visivelInicialmente)
                    } else {
                        matrizResultado[indiceLinha][indiceColuna] = Pair(" ", false)
                    }
                    indiceColuna++
                }
            }
            indiceLinha++
        }
        return matrizResultado
    } else {
        return Array(0) { Array(0) { Pair(" ", false) } }
    }
}


fun validaTerreno(matriz: Array<Array<Pair<String, Boolean>>>?): Boolean {
    if (matriz == null || matriz.isEmpty() || matriz[0].isEmpty()) return false
    val numLinhas = matriz.size
    val numColunas = matriz[0].size
    var linha = 0
    while (linha < numLinhas) {
        if (matriz[linha].size != numColunas) return false
        var coluna = 0
        while (coluna < numColunas) {
            val (conteudo, visivel) = matriz[linha][coluna]
            if (conteudo.length != 1) return false
            val caractere = conteudo[0]
            val eJogador = caractere == 'J'
            val eFinalMinusculo = caractere == 'f'
            val eFinalMaiusculo = caractere == 'F'
            val eMina = caractere == '*'
            val eEspaco = caractere == ' '
            val eNumero = caractere in '1'..'9'
            val caractereValido = eJogador ||
                        eFinalMinusculo ||
                        eFinalMaiusculo ||
                        eMina ||
                        eEspaco ||
                        eNumero

            if (!caractereValido) {
                return false
            }

            if (linha == 0 && coluna == 0 && (conteudo != "J" || !visivel)) return false
            val eUltimaLinha = linha == numLinhas - 1
            val eUltimaColuna = coluna == numColunas - 1
            val eFinal = conteudo == "f" || conteudo == "F"
            val finalNaoVisivel = !visivel

            if (eUltimaLinha && eUltimaColuna && eFinal && finalNaoVisivel) return false



            val jogadorForaInicio =
                conteudo == "J" && (linha != 0 || coluna != 0)

            val finalForaDestino =
                (conteudo == "f" || conteudo == "F") &&
                        (linha != numLinhas - 1 || coluna != numColunas - 1)

            if (jogadorForaInicio || finalForaDestino) return false

            coluna++
        }
        linha++
    }
    return true
}

fun pedeNome(invalido: String): String {
    var nomevalido = false
    var nome = ""
    while (!nomevalido) {
        println("Introduz o nome do jogador")
        nome = readLine() ?: ""
        if (validaNome(nome)) {
            nomevalido = true
        } else {
            println(invalido)
        }
    }
    return nome
}

fun pedeLegenda(invalido: String): Boolean {
    var mostraLegenda: Boolean? = null
    while (mostraLegenda == null) {
        println("Mostrar legenda (s/n)?")
        val legenda = readLine()
        when (legenda) {
            "s" -> mostraLegenda = true
            "n" -> mostraLegenda = false
            else -> println(invalido)
        }
    }
    return mostraLegenda
}

fun pedeLinhas(invalido: String): Int {
    var linhas = 0
    var valido = false
    while (!valido) {
        println("Quantas linhas?")
        val linhasEntrada = readLine()?.toIntOrNull()
        if (linhasEntrada != null && linhasEntrada >= 1) {
            linhas = linhasEntrada
            valido = true
        } else {
            println(invalido)
        }
    }
    return linhas
}

fun pedeColunas(invalido: String): Int {
    var colunas = 0
    var valido = false
    while (!valido) {
        println("Quantas colunas?")
        val colunasEntrada = readLine()?.toIntOrNull()
        if (colunasEntrada != null && colunasEntrada > 0 && colunasEntrada <= 26) {
            colunas = colunasEntrada
            valido = true
        } else {
            println(invalido)
        }
    }
    return colunas
}

fun pedeMinas(invalido: String, linhas: Int, colunas: Int): Int {
    var minas = 0
    var valido = false
    while (!valido) {
        println("Quantas minas (ou enter para o valor por omissao)?")
        val omissao = readLine()
        if (omissao == null || omissao == "") {
            minas = calculaNumeroDeMinas(linhas, colunas)
            valido = true
        } else {
            val minasTerreno = omissao.toIntOrNull()
            if (minasTerreno != null && validaNumeroDeMinas(linhas, colunas, minasTerreno)) {
                minas = minasTerreno
                valido = true
            } else {
                println(invalido)
            }
        }
    }
    return minas
}


fun jogar(matriz: Array<Array<Pair<String, Boolean>>>, mostraLegenda: Boolean) {
    var jogoTerminado = false

    var linhajogador = 0
    var colunajogador = 0
    var linha = 0
    while(linha < matriz.size) {
        var coluna = 0
        while(coluna < matriz[0].size) {
            if (matriz[linha][coluna].first == "J") {
                linhajogador = linha
                colunajogador = coluna
            }
            coluna++
        }
        linha++
    }

    revelaMatriz(matriz, linhajogador, colunajogador)   //Revela á volta da posição inicial

    while (!jogoTerminado) {
        println(criaTerreno(matriz, mostraLegenda))   //Mostra tabuleiro
        println("Introduz a celula destino (ex: 2D)")
        val input = readLine()
        if (input == null) return
        if (input == "0") return   //Sai de jogo
        if (input == "sair") return   //Sai de jogo
        val coord = obtemCoordenadas(input)

        if (coord != null && validaCoordenadasDentroTerreno(coord, matriz.size, matriz[0].size)) {
            val (y, x) = coord

            if (validaMovimentoJogador(Pair(linhajogador, colunajogador), Pair(y, x))) {
                val conteudoDestino = matriz[y][x].first
                if (conteudoDestino == "*") {
                    println("Perdeu o jogo")
                    println(criaTerreno(matriz, mostraLegenda, mostraTudo = true))
                    jogoTerminado = true
                } else if (conteudoDestino == "f" || conteudoDestino == "F") {
                    println("Parabens! Chegou a meta")
                    matriz[linhajogador][colunajogador] = Pair(" ", true)   //Limpa casa antiga
                    matriz[y][x] = Pair("J", true)   //J está na meta
                    println(criaTerreno(matriz, mostraLegenda))
                    jogoTerminado = true
                } else {
                    matriz[linhajogador][colunajogador] = Pair(" ", false)   //Limpa casa antiga
                    matriz[y][x] = Pair("J", true)   //Nova posição do J
                    linhajogador = y
                    colunajogador = x
                    if (contaMinasPerto(matriz, linhajogador, colunajogador) == 0) {
                        revelaMatriz(matriz, linhajogador, colunajogador)   //Revela à volta se não houver minas ao lado
                    }
                }
            } else {
                println("Movimento invalido.")
            }
        } else {

            println("Movimento invalido.")
        }
    }
}

fun main() {
    var querSair = false
    val invalido = "Resposta invalida."

    while (!querSair) {
        println(criaMenu())
        val entrada = readLine()
        if (entrada == null){
            return
        }
        val opcao = entrada?.toIntOrNull()

        when (opcao) {
            1 -> {
                val nome = pedeNome(invalido)
                val legenda = pedeLegenda(invalido)
                val linhas = pedeLinhas(invalido)
                val colunas = pedeColunas(invalido)
                val minas = pedeMinas(invalido, linhas, colunas)

                val matriz = geraMatrizTerreno(linhas, colunas, minas)
                preencheNumMinasNoTerreno(matriz)
                jogar(matriz, legenda)
                return
            }
            2 -> {
                val nome = pedeNome(invalido)
                val legenda = pedeLegenda(invalido)
                val linhas = pedeLinhas(invalido)
                val colunas = pedeColunas(invalido)

                println("Qual o ficheiro de jogo a carregar?")
                val ficheiro = readLine()
                val matriz = lerFicheiroJogo(ficheiro, linhas, colunas)

                if (matriz != null) {
                    preencheNumMinasNoTerreno(matriz)
                    jogar(matriz, legenda)
                }
                return
            }
            0 -> {
                querSair = true
            }
            else -> {
                println(invalido)
            }
        }
    }
}