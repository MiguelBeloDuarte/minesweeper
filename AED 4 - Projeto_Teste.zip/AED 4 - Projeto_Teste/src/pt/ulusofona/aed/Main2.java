package pt.ulusofona.aed;

import java.util.Arrays;

public class Main2 {
    //Essa função extra uma parte da string e converte para maiusculas
    static String obtemSubStringMaiuscula(String s, int inicio, int fim ){
        if(s == "" || s == null){
            return "";
        }
        //Extrai o intervalo de caractere entre inicio e fim
        String palavra = s.substring(inicio, fim);
        //Retorna a nova string em letras maiusculas
        return palavra.toUpperCase();
    }

    static int multiplosDe3(int [] array){
        if (array.length == 0){
            return 0;
        }
        int count = 0;
        if (array[0] % 3 == 0){
            count = 1;
        }
        int[] resto = Arrays.copyOfRange(array, 1, array.length);
        return  count + multiplosDe3(resto);

    }

    static int aednacci (int n){
        if(n == 0){
            return 0;
        }
        if (n == 1){
            return 1;
        }
        return aednacci(n - 1) + aednacci(n - 2) + n;
    }

    static boolean sequenciaAlgarismos (String s, int pos){
        if (s.length() == 0 || s == null || pos != 0){
            return false;
        }
        char number = s.charAt(pos);
        boolean isNumber = Character.isDigit(number);
        if (!isNumber) {
            return false; // Se encontrar algo que não é número, para e retorna falso
        } else {
            // ERRO 2: 'pos++' passa o valor atual e SÓ DEPOIS incrementa.
            // Isso causa uma recursão infinita (StackOverflowError) na mesma posição.
            return sequenciaAlgarismos(s, pos + 1);
        }
    }

    static void main(String[] args) {
        System.out.println(aednacci( 3));
        String teste1 = "12345";
        System.out.println("A string '" + teste1 + "' só tem números? " + sequenciaAlgarismos(teste1, 0));


    }
}
