package pt.ulusofona.aed;

import java.util.Arrays;

public class Main {
    static String obtemPrimeiros3(String palavra) {
        if (palavra == null){
            return null;
        }
        if (palavra.length() <= 3) {
            return palavra;
        }
        return palavra.substring(0,3);
    }

    static String  seq5em5(int n) {
        if (n == 0) {
            return "0";
        }
        return seq5em5(n - 1) + "," + (5 * n);
    }

    static boolean souCapicua(int[] arrayA) {
        if (arrayA == null) {
            return false;
        }
        if (arrayA.length == 0 || arrayA.length == 1) {
            return true;
        }
        if (arrayA[0] == arrayA[arrayA.length - 1]) {
            int[] arrayB = Arrays.copyOfRange(arrayA, 1, arrayA.length - 1);
            return souCapicua(arrayB);
        } else {
            return false;
        }
    }

    static void main() {
        String palavra = "banana";
        int n = 4;
        int[] arrayA = {1,5,5,5,1};
        System.out.println(obtemPrimeiros3(palavra));
        System.out.println(seq5em5(n));
        System.out.println(souCapicua(arrayA));
    }
}
